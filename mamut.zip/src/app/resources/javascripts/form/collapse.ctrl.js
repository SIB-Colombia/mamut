'use strict';

angular.module('app.controllers.collapse',[])
.controller('CollapseDemoCtrl', ['$scope', function($scope) {
	$scope.isCollapsed = true;
	$scope.isCollapsed_1 = true;
	$scope.isCollapsed_2 = true;
}]);