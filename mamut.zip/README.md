# Catalogue of Biodiversity: Data editor
Data elements editor for plinianCore archive to json persistance
